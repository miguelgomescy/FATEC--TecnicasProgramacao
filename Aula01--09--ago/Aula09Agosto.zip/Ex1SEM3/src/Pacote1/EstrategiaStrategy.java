package Pacote1;

public interface EstrategiaStrategy {

	void atacar(Pais inimigo);
	void concluir (Pais inimigo);
}
