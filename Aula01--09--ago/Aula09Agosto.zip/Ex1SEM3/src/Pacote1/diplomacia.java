package Pacote1;

public class diplomacia implements EstrategiaStrategy {

	@Override
	public void atacar(Pais inimigo) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void concluir(Pais inimigo) {
		// TODO Auto-generated method stub
		
	}

}
