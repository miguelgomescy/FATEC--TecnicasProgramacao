/**
 * 
 */
/**
 * 
 */
module PadraoDecorator {
}