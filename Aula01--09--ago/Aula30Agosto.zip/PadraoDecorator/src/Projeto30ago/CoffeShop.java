/**
 * 
 */
package Projeto30ago;

/**
 * 
 */
public class CoffeShop {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		HouseBlend houseblend = new Milk(houseblend);
		System.out.println(houseblend.getDescription() + ":" + houseblend.cost());
		 
		Milk // tem que terminar de copiar
	}

}
